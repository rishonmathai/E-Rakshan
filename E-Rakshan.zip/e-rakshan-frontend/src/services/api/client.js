/* Thin fetch wrapper for the FastAPI backend (see solution doc §6).
   In DEMO_MODE every endpoint is served by the in-browser mock layer. */
const BASE = import.meta.env.VITE_API_BASE_URL || '/api/v1';
export const DEMO_MODE = String(import.meta.env.VITE_DEMO_MODE ?? 'true') === 'true';

async function request(path, { method = 'GET', body, timeoutMs = 8000 } = {}) {
  if (DEMO_MODE) throw new Error('DEMO_MODE active — route the call through services/mock instead.');
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method, signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error(`API ${res.status} on ${path}`);
    return await res.json();
  } finally { clearTimeout(t); }
}

export const api = {
  get: (p) => request(p),
  post: (p, body) => request(p, { method: 'POST', body }),
  patch: (p, body) => request(p, { method: 'PATCH', body }),
};
