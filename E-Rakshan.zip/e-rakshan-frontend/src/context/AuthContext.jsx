import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { mockLogin } from '../services/mock/mockApi';
import { loadLS, saveLS } from '../utils/storage';
import { ROLES } from '../constants/app';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => loadLS('session', null));

  const login = useCallback(async (email, password) => {
    const u = await mockLogin(email, password);
    setUser(u);
    saveLS('session', u);
    return u;
  }, []);

  const logout = useCallback(() => { setUser(null); saveLS('session', null); }, []);

  const can = useCallback((roles) => !roles || !user || roles.includes(user.role), [user]);

  const value = useMemo(() => ({
    user, login, logout, can, isAuthenticated: !!user,
    isCommander: user?.role === ROLES.COMMANDER,
  }), [user, login, logout, can]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
